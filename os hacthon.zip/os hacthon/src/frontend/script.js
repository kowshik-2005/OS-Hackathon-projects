let files = [];
const diskSize = 2000; // Total size of the disk in blocks
let allocatedBlocks = 0;

// Create a file
function createFile() {
    const fileName = document.getElementById('fileName').value.trim();
    const fileSize = parseInt(document.getElementById('fileSize').value);
    const allocationType = document.getElementById('allocationType').value;

    if (!fileName || isNaN(fileSize) || fileSize <= 0) {
        document.getElementById('createFileMessage').innerText = 'Please enter valid file details.';
        return;
    }

    if (allocatedBlocks + fileSize > diskSize) {
        document.getElementById('createFileMessage').innerText = 'Not enough space on the disk.';
        return;
    }

    files.push({ fileName, fileSize, allocationType });
    allocatedBlocks += fileSize;

    document.getElementById('createFileMessage').innerText = `File "${fileName}" created with size ${fileSize} blocks.`;
}

// Delete a file
function deleteFile() {
    const fileName = document.getElementById('deleteFileName').value.trim();
    const fileIndex = files.findIndex(file => file.fileName === fileName);

    if (fileIndex === -1) {
        document.getElementById('deleteFileMessage').innerText = `File "${fileName}" not found.`;
        return;
    }

    const deletedFile = files.splice(fileIndex, 1)[0];
    allocatedBlocks -= deletedFile.fileSize;

    document.getElementById('deleteFileMessage').innerText = `File "${fileName}" deleted.`;
}

// Display disk status
function displayDiskStatus() {
    const freeSpace = diskSize - allocatedBlocks;
    document.getElementById('diskStatus').innerText = `Disk Status: ${freeSpace} blocks free, ${allocatedBlocks} blocks allocated.`;
}

// Display files in a formatted manner
function displayFiles() {
    const fileListElement = document.getElementById('fileList');
    if (files.length === 0) {
        fileListElement.innerText = 'No files found.';
    } else {
        fileListElement.innerText = files.map(file => 
            `File Name: ${file.fileName}\nFile Size: ${file.fileSize}\nAllocation Type: ${file.allocationType}`
        ).join('\n\n'); // Join each file's details with two new lines for separation
    }
}

// Add event listener for formatted file output
document.getElementById('displayFiles').addEventListener('click', function() {
    const output = files.map(file => 
        `File Name: ${file.fileName}\nFile Size: ${file.fileSize}\nAllocation Type: ${file.allocationType}`
    ).join('\n\n'); // Join each file's details with two new lines for separation

    document.getElementById('fileOutput').innerText = output;
});
